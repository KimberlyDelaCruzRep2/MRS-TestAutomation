﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;

namespace MRS.TestAutomation.Pages
{
    public class DashboardPage
    {
        [FindsBy(How = How.XPath, Using = "//li[contains(.,'admin')]")]
        protected IWebElement UserNameTxt { get; set; }

        private IWebDriver _driver;

        public DashboardPage(IWebDriver driver)
        {
            _driver = driver;
            PageFactory.InitElements(_driver, this);
        }

        public string GetUser()
        {
            var usernameValue = _driver.FindElement(By.XPath("//li[contains(.,'admin')]"));
            return usernameValue.Text;
        }

        public Boolean IsUserLoggedIn()
        {
            var result = GetUser();

            if (result != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //public bool IsDashboardExisting()
        //{
        //    var isFound = _driver.FindElement(By.Id("home-container"));
        //    return isFound;
        //}

        //public bool IsAlreadyLoggedIn()
        //{
        //    var isFound = _driver.FindElement(By.XPath("//li[@class ='logout']"));
        //}
    }
}
