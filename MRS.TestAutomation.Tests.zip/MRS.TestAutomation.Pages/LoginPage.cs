﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;

namespace MRS.TestAutomation.Pages
{
    public class LoginPage
    {
        #region Properties
        [FindsBy(How = How.Id, Using = "username")]
        private IWebElement UsernameTxtbox { get; set; }

        [FindsBy(How = How.Id, Using = "password")]
        private IWebElement PasswordTxtbox { get; set; }

        [FindsBy(How = How.Id, Using = "error-message")]
        private IWebElement ErrorMsg { get; set; }

        [FindsBy(How = How.XPath, Using = "//li[@id = 'Inpatient Ward']")]
        private IWebElement InPatientWardLocationLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='loginButton']")]
        private IWebElement LoginButton { get; set; }

        
        private IWebDriver _driver;

        #endregion

        #region Constructor

        public LoginPage(IWebDriver driver)
        {
            _driver = driver;
            PageFactory.InitElements(_driver, this);
        }

        #endregion

        #region Public Method

        public void GoToLoginPage()
        {
            _driver.Navigate().GoToUrl("https://demo.openmrs.org/openmrs/login.htm");
            _driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(10);
        }

        public DashboardPage LoginAs(string username, string password)
        {
            Login(username, password);
            return new DashboardPage(_driver);
        }

        public LoginPage LoginUnsuccessfully(string username, string password)
        {
            Login(username, password);
            return this;
        }

        public string GetErrorMessage()
        {
            return ErrorMsg.Text;
        }

        public void Login(string username, string password)
        {
            UsernameTxtbox.SendKeys(username);
            PasswordTxtbox.SendKeys(password);
            InPatientWardLocationLink.Click();
            LoginButton.Click();
        }

        #endregion
    }
}
