﻿using System;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using MRS.TestAutomation.Pages;

namespace MRS.TestAutomation.Tests.Steps
{
    [Binding]
    public class LoginSteps
    {
        private IWebDriver _driver;

        public LoginSteps()
        {
            _driver = FeatureContext.Current.Get<IWebDriver>("thisDriver");
        }


        [Given(@"I navigate to Log in page")]
        public void GivenINavigateToLogInPage()
        {
            LoginPage loginPage = new LoginPage(_driver);
            loginPage.GoToLoginPage();
        }

        [When(@"I login with username '(.*)' and password '(.*)' in the page")]
        public void WhenILoginWithUsernameAndPasswordInThePage(string username, string password)
        {
            LoginPage loginPage = new LoginPage(_driver);
            loginPage.LoginAs(username, password);

        }
        
        [When(@"Login with an invalid username ''(.*)'Admin(.*)' in the page")]
        public void WhenLoginWithAnInvalidUsernameAdminInThePage(string p0, int p1)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"I should be able to login successfully")]
        public void ThenIShouldBeAbleToLoginSuccessfully()
        {
            DashboardPage dashboardPage = new DashboardPage(_driver);
            Assert.IsTrue(dashboardPage.IsUserLoggedIn());
        }
        
        [Then(@"user should not be able to login successfully")]
        public void ThenUserShouldNotBeAbleToLoginSuccessfully()
        {
            ScenarioContext.Current.Pending();
        }
    }
}
