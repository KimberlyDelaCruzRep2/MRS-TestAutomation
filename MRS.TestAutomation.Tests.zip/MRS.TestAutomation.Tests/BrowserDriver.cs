﻿using System;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using TechTalk.SpecFlow;
using OpenQA.Selenium.Firefox;

namespace MRS.TestAutomation.Steps
{
    [Binding]
    public class BrowserDriver
    {
        private IWebDriver _driver;

        [BeforeScenario]
        public void RunBeforeScenario()
        {
            _driver = new ChromeDriver();
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            _driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(10);
            _driver.Manage().Window.Maximize();
            FeatureContext.Current.Add("thisDriver", _driver);
        }

        [AfterScenario]
        public void RunAfterScenario()
        {
            _driver?.Quit();
        }
    }
}
